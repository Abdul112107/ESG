import React, { useState, useEffect } from 'react';
import { Plus, Edit2, BarChart3, ShieldCheck, HeartHandshake, Trees, Info } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { api } from '../services/api';
import { ESGMetric } from '../types';
import { useAuth } from '../context/AuthContext';
import { KPICard } from '../components/common/KPICard';
import { ChartCard } from '../components/common/ChartCard';
import { FormDialog } from '../components/common/FormDialog';
import { LoadingState, ErrorState } from '../components/common/FeedbackStates';

export const ESGPage: React.FC = () => {
  const { canEdit, isAuditor } = useAuth();
  const [metrics, setMetrics] = useState<ESGMetric[]>([]);
  const [latest, setLatest] = useState<ESGMetric | null>(null);
  const [history, setHistory] = useState<ESGMetric[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<ESGMetric | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Form Fields
  const [reportingPeriod, setReportingPeriod] = useState('2026-Q2');
  const [environmentalScore, setEnvironmentalScore] = useState<number>(85);
  const [socialScore, setSocialScore] = useState<number>(80);
  const [governanceScore, setGovernanceScore] = useState<number>(90);
  const [notes, setNotes] = useState<string>('Evaluated using ISO 14001, GRI Standards and EcoTrack corporate scoring methodology');

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.getESGMetrics();
      if (res.success) {
        setMetrics(res.data);
        setLatest(res.latest);
        setHistory(res.history);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load ESG metrics.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setReportingPeriod('2026-Q2');
    setEnvironmentalScore(86);
    setSocialScore(82);
    setGovernanceScore(91);
    setNotes('Quarterly ESG evaluation update');
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (m: ESGMetric) => {
    setEditingRecord(m);
    setReportingPeriod(m.reportingPeriod);
    setEnvironmentalScore(m.environmentalScore);
    setSocialScore(m.socialScore);
    setGovernanceScore(m.governanceScore);
    setNotes(m.notes || '');
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (environmentalScore < 0 || environmentalScore > 100 || socialScore < 0 || socialScore > 100 || governanceScore < 0 || governanceScore > 100) {
      setFormError('All category scores must be between 0 and 100.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);
    try {
      if (editingRecord) {
        await api.updateESGMetric(editingRecord._id || editingRecord.id!, {
          reportingPeriod,
          environmentalScore,
          socialScore,
          governanceScore,
          notes
        });
      } else {
        await api.createESGMetric({
          reportingPeriod,
          environmentalScore,
          socialScore,
          governanceScore,
          notes
        });
      }
      setIsFormOpen(false);
      await loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save ESG metric.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const previewOverall = Math.round(((environmentalScore + socialScore + governanceScore) / 3) * 10) / 10;

  if (isLoading) {
    return <LoadingState message="Loading ESG performance indicators..." />;
  }

  if (error) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <KPICard
          label="Overall ESG Score"
          value={latest?.overallScore ?? 84.3}
          unit="/ 100"
          icon={BarChart3}
          trend={{ value: '+5.3 pts', isPositive: true, label: 'composite index' }}
          badge="Formula: (E+S+G) / 3"
        />
        <KPICard
          label="Environmental Pillar"
          value={latest?.environmentalScore ?? 85}
          unit="/ 100"
          icon={Trees}
          subtext="Energy, GHG, waste circularity"
        />
        <KPICard
          label="Social Pillar"
          value={latest?.socialScore ?? 80}
          unit="/ 100"
          icon={HeartHandshake}
          subtext="Ergonomics, DEI, training"
        />
        <KPICard
          label="Governance Pillar"
          value={latest?.governanceScore ?? 88}
          unit="/ 100"
          icon={ShieldCheck}
          subtext="Ethics, board oversight, risk"
        />
      </div>

      {/* Historical Trend Chart */}
      <ChartCard
        title="Historical ESG Pillar Index Trajectory"
        subtitle="Tracking quarterly performance progress across all three ESG pillars"
        action={
          canEdit ? (
            <button
              onClick={handleOpenAdd}
              className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg inline-flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Quarter Assessment</span>
            </button>
          ) : undefined
        }
        footerNote="Normalized on a 0-100 scale using verifiable operational and governance data"
      >
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={history} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="reportingPeriod" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Bar dataKey="environmentalScore" fill="#059669" name="Environmental (E)" radius={[3, 3, 0, 0]} />
            <Bar dataKey="socialScore" fill="#0284c7" name="Social (S)" radius={[3, 3, 0, 0]} />
            <Bar dataKey="governanceScore" fill="#475569" name="Governance (G)" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Evaluation Methodology & Criteria Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Trees className="w-4 h-4 text-emerald-700" />
            <h4 className="text-sm font-semibold text-slate-900">Environmental Criteria</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Measures resource conservation, clean energy adoption, GHG emission intensity per unit output, and hazardous waste diversion.
          </p>
          <ul className="text-xs text-slate-700 space-y-1 pt-1 list-disc list-inside">
            <li>Energy Efficiency Index: <span className="font-semibold text-slate-900">88 / 100</span></li>
            <li>Carbon Abatement: <span className="font-semibold text-slate-900">84 / 100</span></li>
            <li>Waste Circularity: <span className="font-semibold text-slate-900">89 / 100</span></li>
          </ul>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-4 h-4 text-sky-700" />
            <h4 className="text-sm font-semibold text-slate-900">Social Criteria</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Evaluates occupational health and safety (OSHA compliant), workforce retention, continuous professional development, and community impact.
          </p>
          <ul className="text-xs text-slate-700 space-y-1 pt-1 list-disc list-inside">
            <li>Occupational Health & Safety: <span className="font-semibold text-slate-900">82 / 100</span></li>
            <li>Workplace Training Hours: <span className="font-semibold text-slate-900">78 / 100</span></li>
            <li>Employee Retention: <span className="font-semibold text-slate-900">80 / 100</span></li>
          </ul>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-slate-700" />
            <h4 className="text-sm font-semibold text-slate-900">Governance Criteria</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Validates anti-corruption policies, whistleblower protection, board independence, supply chain transparency, and audit readiness.
          </p>
          <ul className="text-xs text-slate-700 space-y-1 pt-1 list-disc list-inside">
            <li>Compliance & Ethics: <span className="font-semibold text-slate-900">92 / 100</span></li>
            <li>Risk Management Matrix: <span className="font-semibold text-slate-900">86 / 100</span></li>
            <li>Third-party Audit Score: <span className="font-semibold text-slate-900">90 / 100</span></li>
          </ul>
        </div>
      </div>

      {/* Historical Audit Table */}
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <h4 className="text-sm font-semibold text-slate-900 mb-3">Audit Logs & Verification History</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-600 uppercase">
                <th className="py-2.5 px-3">Reporting Period</th>
                <th className="py-2.5 px-3 text-right">Environmental</th>
                <th className="py-2.5 px-3 text-right">Social</th>
                <th className="py-2.5 px-3 text-right">Governance</th>
                <th className="py-2.5 px-3 text-right">Overall Index</th>
                <th className="py-2.5 px-3">Methodology / Notes</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {metrics.map(m => (
                <tr key={m._id || m.id} className="hover:bg-slate-50">
                  <td className="py-3 px-3 font-semibold text-slate-900">{m.reportingPeriod}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700">{m.environmentalScore}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-sky-700">{m.socialScore}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">{m.governanceScore}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">{m.overallScore}</td>
                  <td className="py-3 px-3 text-slate-500 max-w-xs truncate">{m.notes || m.methodologyVersion}</td>
                  <td className="py-3 px-3 text-right">
                    {canEdit && (
                      <button
                        onClick={() => handleOpenEdit(m)}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                        title="Edit score"
                      >
                        <Edit2 className="w-3.5 h-3.5 inline" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Dialog */}
      <FormDialog
        isOpen={isFormOpen}
        title={editingRecord ? 'Edit ESG Period Assessment' : 'Log New ESG Evaluation'}
        subtitle="Documented formula: Overall Score = (E + S + G) / 3 on 0-100 scale"
        onClose={() => setIsFormOpen(false)}
        onSubmit={handleSubmit}
        isLoading={isSubmitting}
        error={formError}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Reporting Period</label>
            <input
              type="text"
              required
              value={reportingPeriod}
              onChange={(e) => setReportingPeriod(e.target.value)}
              placeholder="e.g. 2026-Q2 or 2026-FullYear"
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Environmental Score (0-100)</label>
            <input
              type="number"
              min="0"
              max="100"
              required
              value={environmentalScore}
              onChange={(e) => setEnvironmentalScore(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Social Score (0-100)</label>
            <input
              type="number"
              min="0"
              max="100"
              required
              value={socialScore}
              onChange={(e) => setSocialScore(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Governance Score (0-100)</label>
            <input
              type="number"
              min="0"
              max="100"
              required
              value={governanceScore}
              onChange={(e) => setGovernanceScore(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Evaluation Methodology & Audit Notes</label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          />
        </div>

        <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
          <div>
            <span className="font-semibold text-slate-900 block">Overall Composite ESG Score:</span>
            <span className="text-[11px] text-slate-500 font-mono">({environmentalScore} + {socialScore} + {governanceScore}) / 3</span>
          </div>
          <span className="text-lg font-bold font-mono text-emerald-700">{previewOverall} / 100</span>
        </div>
      </FormDialog>
    </div>
  );
};
