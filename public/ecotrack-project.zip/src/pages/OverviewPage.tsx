import React, { useState, useEffect } from 'react';
import {
  Zap,
  CloudRain,
  Trash2,
  BarChart3,
  ArrowRight,
  Target,
  FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { api } from '../services/api';
import { DashboardOverview, TrendDataPoint } from '../types';
import { KPICard } from '../components/common/KPICard';
import { ChartCard } from '../components/common/ChartCard';
import { LoadingState, ErrorState } from '../components/common/FeedbackStates';

interface OverviewPageProps {
  selectedYear: string;
  onNavigateTab: (tab: any) => void;
  onOpenReportGenerator: () => void;
}

const SCOPE_COLORS: Record<string, string> = {
  'Scope 1': '#059669', // Emerald
  'Scope 2': '#0284c7', // Sky
  'Scope 3': '#d97706', // Amber
};

export const OverviewPage: React.FC<OverviewPageProps> = ({
  selectedYear,
  onNavigateTab,
  onOpenReportGenerator
}) => {
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [trends, setTrends] = useState<TrendDataPoint[]>([]);
  const [emissionsBreakdown, setEmissionsBreakdown] = useState<{
    bySource: Array<{ name: string; value: number; scope: string }>;
    byScope: Array<{ name: string; value: number }>;
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [overviewRes, trendsRes, emissionsRes] = await Promise.all([
        api.getDashboardOverview({ year: selectedYear }),
        api.getDashboardTrends({ year: selectedYear }),
        api.getEmissionsBySource({
          startDate: selectedYear ? `${selectedYear}-01-01` : undefined,
          endDate: selectedYear ? `${selectedYear}-12-31` : undefined
        })
      ]);

      if (overviewRes.success) setData(overviewRes.data);
      if (trendsRes.success) setTrends(trendsRes.data);
      if (emissionsRes.success) setEmissionsBreakdown(emissionsRes.data);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve overview metrics.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, [selectedYear]);

  if (isLoading) {
    return <LoadingState message="Calculating enterprise ESG aggregations from database records..." />;
  }

  if (error || !data) {
    return <ErrorState message={error || 'No overview data available.'} onRetry={loadDashboard} />;
  }

  const { kpis, goals, recentActivity } = data;

  return (
    <div className="space-y-6">
      {/* 4 Core Executive KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Total Energy Consumption"
          value={kpis.totalEnergyKWh}
          unit="kWh"
          trend={{ value: '-6.4%', isPositive: true, label: 'efficiency gain' }}
          icon={Zap}
          badge={`Cost: $${kpis.totalEnergyCost.toLocaleString()}`}
        />

        <KPICard
          label="Carbon Emissions"
          value={kpis.totalEmissionsTCO2e}
          unit="tCO2e"
          trend={{ value: '-8.1%', isPositive: true, label: 'Scope 1-3 reduction' }}
          icon={CloudRain}
          badge="GHG Protocol"
        />

        <KPICard
          label="Waste Diversion Rate"
          value={`${kpis.wasteRecyclingRate}%`}
          subtext={`${kpis.recycledWasteKg.toLocaleString()} kg recycled`}
          trend={{ value: '+4.2%', isPositive: true, label: 'diverted from landfill' }}
          icon={Trash2}
          badge="Zero-Waste"
        />

        <KPICard
          label="Overall ESG Score"
          value={`${kpis.overallESGScore}`}
          unit="/ 100"
          trend={{ value: '+5.3 pts', isPositive: true, label: 'composite index' }}
          icon={BarChart3}
          badge={`E:${kpis.environmentalScore} S:${kpis.socialScore} G:${kpis.governanceScore}`}
        />
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Energy & Emissions Dual Axis Trend */}
        <div className="lg:col-span-2">
          <ChartCard
            title="Monthly Energy & Carbon Emission Trajectory"
            subtitle="Comparing normalized kilowatt-hours vs metric tons CO2 equivalent"
            action={
              <button
                onClick={() => onNavigateTab('energy')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1"
              >
                <span>View Records</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            }
            footerNote="Data sourced from MongoDB EnergyRecord & EmissionRecord collections"
          >
            {trends.length === 0 ? (
              <p className="text-xs text-slate-400">No monthly records in selected period.</p>
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <ComposedChart data={trends} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="left" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderColor: '#e2e8f0',
                      borderRadius: '8px',
                      fontSize: '12px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Bar yAxisId="left" dataKey="energyKWh" fill="#0284c7" radius={[4, 4, 0, 0]} name="Energy (kWh)" />
                  <Line yAxisId="right" type="monotone" dataKey="emissionsTCO2e" stroke="#059669" strokeWidth={2.5} dot={{ r: 3 }} name="Emissions (tCO2e)" />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </ChartCard>
        </div>

        {/* Carbon Emissions by Scope / Source */}
        <div className="lg:col-span-1">
          <ChartCard
            title="Emissions by Scope"
            subtitle="Scope 1 Direct, Scope 2 Electricity, Scope 3 Value Chain"
            action={
              <button
                onClick={() => onNavigateTab('emissions')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800"
              >
                Scope Data
              </button>
            }
          >
            {!emissionsBreakdown?.byScope || emissionsBreakdown.byScope.length === 0 ? (
              <p className="text-xs text-slate-400">No emission breakdown data available.</p>
            ) : (
              <div className="w-full flex flex-col items-center">
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={emissionsBreakdown.byScope}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {emissionsBreakdown.byScope.map((entry) => (
                        <Cell key={entry.name} fill={SCOPE_COLORS[entry.name] || '#64748b'} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>

                <div className="w-full space-y-1.5 pt-2 text-xs border-t border-slate-100">
                  {emissionsBreakdown.byScope.map((item) => (
                    <div key={item.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: SCOPE_COLORS[item.name] || '#64748b' }}
                        />
                        <span className="text-slate-600 font-medium">{item.name}</span>
                      </div>
                      <span className="font-mono tabular-nums text-slate-900 font-semibold">
                        {item.value} tCO2e
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </ChartCard>
        </div>
      </div>

      {/* Goals Progress & Recent Logs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sustainability Goals Quick Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 tracking-tight">Active Sustainability Targets</h3>
                <p className="text-xs text-slate-500">Progress evaluated dynamically by direction formula</p>
              </div>
              <button
                onClick={() => onNavigateTab('goals')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1"
              >
                <span>All Goals</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-4">
              {goals.length === 0 ? (
                <p className="text-xs text-slate-400">No active goals configured.</p>
              ) : (
                goals.map(goal => {
                  const p = (goal as any).progress;
                  const pct = p?.percentage ?? 0;
                  return (
                    <div key={goal._id || goal.id} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-medium text-slate-800 truncate max-w-[200px]">{goal.title}</span>
                        <span className="font-mono tabular-nums font-semibold text-slate-900">{pct}%</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            pct >= 100 ? 'bg-emerald-600' : pct >= 60 ? 'bg-sky-600' : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.min(100, Math.max(5, pct))}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>Current: {goal.currentValue} {goal.unit}</span>
                        <span>Target: {goal.targetValue} {goal.unit}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              {kpis.activeGoalsCount} In Progress · {kpis.achievedGoalsCount} Achieved
            </span>
            <button
              onClick={() => onNavigateTab('goals')}
              className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded border border-slate-200 transition-colors"
            >
              Manage Goals
            </button>
          </div>
        </div>

        {/* Recent Database Records Feed */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 tracking-tight">Recent Sustainability Logs</h3>
                <p className="text-xs text-slate-500">Live feed of verified database entries</p>
              </div>
              <button
                onClick={onOpenReportGenerator}
                className="px-3 py-1.5 text-xs font-medium text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 inline-flex items-center gap-1.5 transition-colors"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Export PDF Report</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 overflow-hidden">
              {recentActivity.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No recent records available.</p>
              ) : (
                recentActivity.map(item => (
                  <div key={item.id} className="py-2.5 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 rounded bg-slate-50 border border-slate-100 text-slate-600 shrink-0">
                        {item.category === 'Energy' ? (
                          <Zap className="w-3.5 h-3.5 text-sky-600" />
                        ) : item.category === 'Emissions' ? (
                          <CloudRain className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Trash2 className="w-3.5 h-3.5 text-amber-600" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-medium text-slate-800 block">{item.title}</span>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <span>{item.category}</span>
                          <span aria-hidden="true">·</span>
                          <span>{new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-mono font-semibold text-slate-900 block tabular-nums">
                        {item.value}
                      </span>
                      <span className="text-[10px] text-slate-400">{item.createdBy}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Database persistence: Active</span>
            <span className="font-mono text-[11px] text-slate-400">ISO 14001 Compliant Audit Trail</span>
          </div>
        </div>
      </div>
    </div>
  );
};
