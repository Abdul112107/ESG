import React, { useState } from 'react';
import { Leaf, Lock, Mail, ShieldCheck, ArrowRight } from 'lucide-react';
import { useAuth, DEMO_CREDENTIALS } from '../context/AuthContext';
import { UserRole } from '../types';

interface LoginPageProps {
  onSwitchToRegister: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSwitchToRegister }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('admin@ecotrack.org');
  const [password, setPassword] = useState('Admin@EcoTrack2026!');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      await login(email, password);
    } catch (err: any) {
      setError(err.message || 'Login failed. Please verify credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoLogin = (role: UserRole) => {
    const cred = DEMO_CREDENTIALS[role];
    setEmail(cred.email);
    setPassword(cred.pass);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        {/* Brand Lockup */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-600 text-white shadow-xs">
            <Leaf className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Sign in to EcoTrack</h2>
          <p className="text-xs text-slate-500">Enterprise ESG Sustainability & Carbon Accounting Platform</p>
        </div>

        {/* Main Login Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-5">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Corporate Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors disabled:opacity-50 shadow-xs flex items-center justify-center gap-1.5"
            >
              <span>{isLoading ? 'Verifying Credentials...' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Accounts Selection */}
          <div className="pt-4 border-t border-slate-100 space-y-2">
            <span className="text-[11px] font-semibold text-slate-600 block uppercase tracking-wider text-center">
              Quick 1-Click Evaluation Roles
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Admin')}
                className="p-2 text-left rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/40 text-xs transition-colors"
              >
                <span className="font-semibold text-slate-800 block text-[11px]">Admin (Executive)</span>
                <span className="text-[10px] text-slate-400 block truncate">Dr. Sarah Jenkins</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Manager')}
                className="p-2 text-left rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/40 text-xs transition-colors"
              >
                <span className="font-semibold text-slate-800 block text-[11px]">Manager (Operations)</span>
                <span className="text-[10px] text-slate-400 block truncate">Marcus Vance</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Employee')}
                className="p-2 text-left rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/40 text-xs transition-colors"
              >
                <span className="font-semibold text-slate-800 block text-[11px]">Employee (Data Entry)</span>
                <span className="text-[10px] text-slate-400 block truncate">Elena Rostova</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Auditor')}
                className="p-2 text-left rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/40 text-xs transition-colors"
              >
                <span className="font-semibold text-slate-800 block text-[11px]">Auditor (Read-Only)</span>
                <span className="text-[10px] text-slate-400 block truncate">Arthur Sterling</span>
              </button>
            </div>
          </div>

          <div className="text-center pt-2">
            <button
              onClick={onSwitchToRegister}
              className="text-xs text-slate-600 hover:text-emerald-700 font-medium transition-colors"
            >
              Don't have an account? Register new user
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
