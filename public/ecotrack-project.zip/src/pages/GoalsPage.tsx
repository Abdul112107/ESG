import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Target, CheckCircle2, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { api } from '../services/api';
import { SustainabilityGoal } from '../types';
import { useAuth } from '../context/AuthContext';
import { KPICard } from '../components/common/KPICard';
import { FormDialog } from '../components/common/FormDialog';
import { ConfirmationDialog } from '../components/common/ConfirmationDialog';
import { LoadingState, ErrorState } from '../components/common/FeedbackStates';

export const GoalsPage: React.FC = () => {
  const { canEdit } = useAuth();
  const [goals, setGoals] = useState<SustainabilityGoal[]>([]);
  const [summary, setSummary] = useState<{ total: number; active: number; achieved: number }>({
    total: 0,
    active: 0,
    achieved: 0
  });

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<SustainabilityGoal | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SustainabilityGoal | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [metricType, setMetricType] = useState<SustainabilityGoal['metricType']>('Energy Reduction');
  const [baselineValue, setBaselineValue] = useState<number>(50000);
  const [currentValue, setCurrentValue] = useState<number>(42000);
  const [targetValue, setTargetValue] = useState<number>(35000);
  const [unit, setUnit] = useState('kWh/mo');
  const [baselineDate, setBaselineDate] = useState('2024-01-01');
  const [targetDate, setTargetDate] = useState('2028-12-31');
  const [status, setStatus] = useState<SustainabilityGoal['status']>('In Progress');

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.getGoals();
      if (res.success) {
        setGoals(res.data);
        setSummary(res.summary);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load sustainability goals.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenAdd = () => {
    setEditingGoal(null);
    setTitle('Water Stewardship & Effluent Reduction');
    setDescription('Reduce fresh industrial water intake across Chicago plant cooling towers by 25%.');
    setMetricType('Water Efficiency');
    setBaselineValue(12000);
    setCurrentValue(10500);
    setTargetValue(9000);
    setUnit('m3/mo');
    setBaselineDate('2024-01-01');
    setTargetDate('2027-12-31');
    setStatus('In Progress');
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (g: SustainabilityGoal) => {
    setEditingGoal(g);
    setTitle(g.title);
    setDescription(g.description);
    setMetricType(g.metricType);
    setBaselineValue(g.baselineValue);
    setCurrentValue(g.currentValue);
    setTargetValue(g.targetValue);
    setUnit(g.unit);
    setBaselineDate(new Date(g.baselineDate).toISOString().split('T')[0]);
    setTargetDate(new Date(g.targetDate).toISOString().split('T')[0]);
    setStatus(g.status);
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setFormError('Title and description are required.');
      return;
    }
    if (baselineValue === targetValue) {
      setFormError('Baseline value and target value cannot be identical.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);
    try {
      if (editingGoal) {
        await api.updateGoal(editingGoal._id || editingGoal.id!, {
          title,
          description,
          metricType,
          baselineValue,
          currentValue,
          targetValue,
          unit,
          baselineDate,
          targetDate,
          status
        });
      } else {
        await api.createGoal({
          title,
          description,
          metricType,
          baselineValue,
          currentValue,
          targetValue,
          unit,
          baselineDate,
          targetDate,
          status
        });
      }
      setIsFormOpen(false);
      await loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save goal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsSubmitting(true);
    try {
      await api.deleteGoal(deleteTarget._id || deleteTarget.id!);
      setDeleteTarget(null);
      await loadData();
    } catch (err: any) {
      alert('Delete failed: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard
          label="Active Strategic Goals"
          value={summary.active}
          unit="targets"
          icon={Target}
          subtext="Under active corporate monitoring"
        />
        <KPICard
          label="Achieved Milestones"
          value={summary.achieved}
          unit="milestones"
          icon={CheckCircle2}
          subtext="Exceeded or completed targets"
        />
        <KPICard
          label="Total Defined Portfolio"
          value={summary.total}
          unit="strategic goals"
          icon={TrendingUp}
          subtext="Stored in MongoDB SustainabilityGoals"
        />
      </div>

      {/* Header Bar */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Corporate Sustainability Commitments</h3>
          <p className="text-xs text-slate-500">Progress evaluated dynamically based on goal direction</p>
        </div>
        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg inline-flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Create Sustainability Target</span>
          </button>
        )}
      </div>

      {/* Goals Grid */}
      {isLoading ? (
        <LoadingState message="Calculating sustainability progress metrics..." />
      ) : error ? (
        <ErrorState message={error} onRetry={loadData} />
      ) : goals.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <p className="text-sm font-semibold text-slate-800">No goals found</p>
          <p className="text-xs text-slate-500 mt-1">Get started by defining your organization's first environmental target.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {goals.map(g => {
            const isReduction = g.isReduction ?? (g.baselineValue > g.targetValue);
            const pct = g.progressPercentage ?? 0;
            const isExceeded = g.isExceeded || pct >= 100;

            return (
              <div
                key={g._id || g.id}
                className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between space-y-4 hover:shadow-xs transition-shadow"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-emerald-800 flex items-center gap-1">
                          {isReduction ? <TrendingDown className="w-3.5 h-3.5 text-emerald-600" /> : <TrendingUp className="w-3.5 h-3.5 text-sky-600" />}
                          {g.metricType}
                        </span>
                        <span className="text-slate-300">·</span>
                        <span className="text-[11px] text-slate-500">{g.status}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 tracking-tight">{g.title}</h4>
                    </div>

                    {canEdit && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleOpenEdit(g)}
                          className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                          title="Edit Goal"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(g)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                          title="Delete Goal"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">{g.description}</p>
                </div>

                {/* Progress Visualizer */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="flex items-baseline justify-between text-xs">
                    <span className="text-slate-500 font-medium">Trajectory Progress</span>
                    <div className="flex items-center gap-1.5 font-mono">
                      {isExceeded && (
                        <span className="text-xs font-semibold text-emerald-700">Target Exceeded!</span>
                      )}
                      <span className="text-sm font-bold text-slate-900">{pct}%</span>
                    </div>
                  </div>

                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        isExceeded ? 'bg-emerald-600' : pct >= 60 ? 'bg-sky-600' : 'bg-amber-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(3, pct))}%` }}
                    />
                  </div>

                  {/* Baseline / Current / Target Metrics */}
                  <div className="grid grid-cols-3 gap-2 pt-1 text-center font-mono">
                    <div className="p-2 rounded bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 block uppercase">Baseline</span>
                      <span className="text-xs font-semibold text-slate-800 tabular-nums">
                        {g.baselineValue} {g.unit}
                      </span>
                    </div>
                    <div className="p-2 rounded bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 block uppercase">Current</span>
                      <span className="text-xs font-bold text-emerald-700 tabular-nums">
                        {g.currentValue} {g.unit}
                      </span>
                    </div>
                    <div className="p-2 rounded bg-slate-50 border border-slate-100">
                      <span className="text-[10px] text-slate-400 block uppercase">Target</span>
                      <span className="text-xs font-semibold text-slate-800 tabular-nums">
                        {g.targetValue} {g.unit}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span>Baseline: {new Date(g.baselineDate).toLocaleDateString()}</span>
                    <span>Deadline: {new Date(g.targetDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Form Dialog */}
      <FormDialog
        isOpen={isFormOpen}
        title={editingGoal ? 'Edit Sustainability Commitment' : 'Create New Target'}
        subtitle="Progress is dynamically calculated using direction formulas"
        onClose={() => setIsFormOpen(false)}
        onSubmit={handleSubmit}
        isLoading={isSubmitting}
        error={formError}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Target Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Commitment Description</label>
            <textarea
              rows={2}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Metric Type</label>
              <select
                value={metricType}
                onChange={(e) => setMetricType(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
              >
                <option value="Energy Reduction">Energy Reduction</option>
                <option value="Carbon Reduction">Carbon Reduction</option>
                <option value="Recycling Rate">Recycling Rate</option>
                <option value="Renewable Share">Renewable Share</option>
                <option value="Water Efficiency">Water Efficiency</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
              >
                <option value="In Progress">In Progress</option>
                <option value="Achieved">Achieved</option>
                <option value="At Risk">At Risk</option>
                <option value="Archived">Archived</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Baseline Value</label>
              <input
                type="number"
                step="any"
                required
                value={baselineValue}
                onChange={(e) => setBaselineValue(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Current Logged Value</label>
              <input
                type="number"
                step="any"
                required
                value={currentValue}
                onChange={(e) => setCurrentValue(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Value</label>
              <input
                type="number"
                step="any"
                required
                value={targetValue}
                onChange={(e) => setTargetValue(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Unit of Measurement</label>
              <input
                type="text"
                required
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="e.g. kWh/mo, tCO2e, %"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Baseline Date</label>
              <input
                type="date"
                required
                value={baselineDate}
                onChange={(e) => setBaselineDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Deadline</label>
              <input
                type="date"
                required
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>
          </div>
        </div>
      </FormDialog>

      {/* Delete Confirmation */}
      <ConfirmationDialog
        isOpen={!!deleteTarget}
        title="Delete Sustainability Goal"
        message={`Are you sure you want to delete the goal "${deleteTarget?.title}"?`}
        confirmLabel="Delete Target"
        isDestructive={true}
        isLoading={isSubmitting}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
