import React, { useState, useEffect } from 'react';
import { Settings, Building, Database, Shield, BookOpen, RefreshCw, CheckCircle2, AlertTriangle, ExternalLink, Download, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { DatabaseStatus, EmissionFactor } from '../types';

interface SettingsPageProps {
  onOpenDbConfig: () => void;
  dbStatus: DatabaseStatus | null;
  onRefreshDbStatus: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  onOpenDbConfig,
  dbStatus,
  onRefreshDbStatus
}) => {
  const { user, organization, isAdmin, refreshProfile } = useAuth();
  const [factors, setFactors] = useState<EmissionFactor[]>([]);

  // Organization edit state
  const [orgName, setOrgName] = useState(organization?.name || 'EcoVerde Industrial Solutions Corp');
  const [industry, setIndustry] = useState(organization?.industry || 'Advanced Manufacturing');
  const [location, setLocation] = useState(organization?.location || 'Austin HQ & Chicago Plant');
  const [currency, setCurrency] = useState(organization?.reportingCurrency || 'USD');
  const [isSavingOrg, setIsSavingOrg] = useState(false);
  const [orgFeedback, setOrgFeedback] = useState<string | null>(null);

  // MongoDB connection string input
  const [mongoUri, setMongoUri] = useState('');
  const [isConnectingMongo, setIsConnectingMongo] = useState(false);
  const [mongoFeedback, setMongoFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    if (organization) {
      setOrgName(organization.name);
      setIndustry(organization.industry);
      setLocation(organization.location);
      setCurrency(organization.reportingCurrency);
    }
  }, [organization]);

  useEffect(() => {
    api.getEmissionFactors().then(res => {
      if (res.success) setFactors(res.data);
    }).catch(console.error);
  }, []);

  const handleSaveOrganization = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setIsSavingOrg(true);
    setOrgFeedback(null);
    try {
      await api.updateOrganization(organization?._id || organization?.id || 'default-org', {
        name: orgName,
        industry,
        location,
        reportingCurrency: currency
      });
      await refreshProfile();
      setOrgFeedback('Organization settings successfully updated.');
    } catch (err: any) {
      setOrgFeedback('Failed to update organization: ' + err.message);
    } finally {
      setIsSavingOrg(false);
    }
  };

  const handleConnectMongo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mongoUri.trim()) return;
    setIsConnectingMongo(true);
    setMongoFeedback(null);
    try {
      const res = await api.connectMongo(mongoUri.trim());
      setMongoFeedback({ type: 'success', message: res.message || 'Successfully connected to MongoDB!' });
      onRefreshDbStatus();
    } catch (err: any) {
      setMongoFeedback({ type: 'error', message: err.message || 'Failed to connect to MongoDB.' });
    } finally {
      setIsConnectingMongo(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-8">
      {/* User Profile Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Current User Profile & Role Permissions</h3>
            <p className="text-xs text-slate-500">Security credentials and role-based access control (RBAC)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-400 block uppercase font-medium">Full Name</span>
            <span className="text-xs font-semibold text-slate-800">{user?.name}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-400 block uppercase font-medium">Email Address</span>
            <span className="text-xs font-semibold text-slate-800">{user?.email}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-400 block uppercase font-medium">Assigned System Role</span>
            <span className="text-xs font-semibold text-emerald-700">{user?.role}</span>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
          <span className="font-semibold text-slate-700">Role Capabilities: </span>
          {user?.role === 'Admin' && 'Full administrative authority (CRUD records, manage organizations, create users, configure database).'}
          {user?.role === 'Manager' && 'Sustainability operational management (CRUD records, run calculations, export reports).'}
          {user?.role === 'Employee' && 'Operational data entry (log energy, emissions, and waste metrics).'}
          {user?.role === 'Auditor' && 'Read-only independent audit compliance access across all verified records and reports.'}
        </div>
      </div>

      {/* Database Connection & Diagnostics */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">MongoDB Database Status</h3>
              <p className="text-xs text-slate-500">Mongoose ODM integration & persistent database storage</p>
            </div>
          </div>

          <button
            onClick={onOpenDbConfig}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors"
          >
            Configure Connection
          </button>
        </div>

        {/* Status Indicator Banner */}
        <div
          className={`p-4 rounded-xl border text-xs leading-relaxed ${
            dbStatus?.connected
              ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
              : 'bg-amber-50/60 border-amber-200 text-amber-900'
          }`}
        >
          <div className="flex items-start gap-2.5">
            {dbStatus?.connected ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <span className="font-semibold block">
                {dbStatus?.connected
                  ? `Live MongoDB Connected (${dbStatus.databaseName || 'ecotrack'})`
                  : 'Operating in Development Mode (Embedded Persistent Store)'}
              </span>
              <p className="text-[11px] opacity-90">{dbStatus?.message}</p>
              {dbStatus?.host && (
                <p className="font-mono text-[10px] opacity-80">Connected host: {dbStatus.host}</p>
              )}
            </div>
          </div>
        </div>

        {/* Live Connect MongoDB Atlas input */}
        <form onSubmit={handleConnectMongo} className="space-y-3 pt-2">
          <label className="block text-xs font-semibold text-slate-800">
            Connect MongoDB Atlas URI:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={mongoUri}
              onChange={e => setMongoUri(e.target.value)}
              placeholder="mongodb+srv://<username>:<password>@cluster0.mongodb.net/ecotrack"
              className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={isConnectingMongo || !mongoUri.trim()}
              className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 shrink-0"
            >
              {isConnectingMongo ? 'Connecting...' : 'Connect Atlas'}
            </button>
          </div>
          {mongoFeedback && (
            <p className={`text-xs ${mongoFeedback.type === 'success' ? 'text-emerald-700' : 'text-red-600'}`}>
              {mongoFeedback.message}
            </p>
          )}
        </form>
      </div>

      {/* Organization Settings */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Organization Preferences</h3>
            <p className="text-xs text-slate-500">Corporate entity parameters and sustainability reporting defaults</p>
          </div>
        </div>

        {orgFeedback && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
            {orgFeedback}
          </div>
        )}

        <form onSubmit={handleSaveOrganization} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Organization Name</label>
              <input
                type="text"
                disabled={!isAdmin}
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 disabled:bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Industry Sector</label>
              <input
                type="text"
                disabled={!isAdmin}
                value={industry}
                onChange={e => setIndustry(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 disabled:bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Operating Facilities / Locations</label>
              <input
                type="text"
                disabled={!isAdmin}
                value={location}
                onChange={e => setLocation(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 disabled:bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Reporting Currency</label>
              <input
                type="text"
                disabled={!isAdmin}
                value={currency}
                onChange={e => setCurrency(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 disabled:bg-slate-50"
              />
            </div>
          </div>

          {isAdmin && (
            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSavingOrg}
                className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors disabled:opacity-50 shadow-xs"
              >
                {isSavingOrg ? 'Saving Changes...' : 'Save Organization Details'}
              </button>
            </div>
          )}
        </form>
      </div>

      {/* Official Emission Factors Reference */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Documented Emission Factors Library</h3>
            <p className="text-xs text-slate-500">Official conversion factors referenced during calculations</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-600 uppercase">
                <th className="py-2.5 px-3">Emission Source</th>
                <th className="py-2.5 px-3">Scope</th>
                <th className="py-2.5 px-3 text-right">Factor (kgCO2e)</th>
                <th className="py-2.5 px-3">Unit</th>
                <th className="py-2.5 px-3">Authority</th>
                <th className="py-2.5 px-3">Version</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
              {factors.map(f => (
                <tr key={f.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-900">{f.sourceName}</td>
                  <td className="py-2.5 px-3 font-sans font-semibold text-emerald-700">{f.scope}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">{f.factor}</td>
                  <td className="py-2.5 px-3">{f.unit}</td>
                  <td className="py-2.5 px-3 font-sans text-slate-600">{f.sourceAuthority}</td>
                  <td className="py-2.5 px-3 text-slate-400">{f.version}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Project Source Code Archive */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Project Source Code ZIP Archive</h3>
              <p className="text-xs text-slate-500">Download the complete codebase including Mongoose models, Express REST API, React UI, seed scripts, and documentation</p>
            </div>
          </div>

          <a
            href="/api/download-zip"
            download="ecotrack-esg-platform.zip"
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg inline-flex items-center gap-2 transition-colors shrink-0 shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Download Project ZIP</span>
          </a>
        </div>
      </div>
    </div>
  );
};
