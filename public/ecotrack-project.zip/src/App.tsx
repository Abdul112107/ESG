import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar, NavItemKey } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DatabaseConfigModal } from './components/common/DatabaseConfigModal';
import { OverviewPage } from './pages/OverviewPage';
import { EnergyPage } from './pages/EnergyPage';
import { EmissionsPage } from './pages/EmissionsPage';
import { WastePage } from './pages/WastePage';
import { ESGPage } from './pages/ESGPage';
import { GoalsPage } from './pages/GoalsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { api } from './services/api';
import { DatabaseStatus } from './types';

const TAB_TITLES: Record<NavItemKey, string> = {
  overview: 'Executive Sustainability Overview',
  energy: 'Energy Management & Utility Costs',
  emissions: 'Greenhouse Gas Carbon Emissions',
  waste: 'Waste Diversion & Circularity',
  esg: 'ESG Pillar Performance Index',
  goals: 'Sustainability Goals & Targets',
  reports: 'Sustainability Reports & PDF Exports',
  settings: 'System & Organization Settings'
};

const MainDashboard: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<NavItemKey>('overview');
  const [selectedYear, setSelectedYear] = useState<string>('2026');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // MongoDB status modal
  const [isDbModalOpen, setIsDbModalOpen] = useState(false);
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);

  const fetchDbStatus = async () => {
    try {
      const res = await api.getDbStatus();
      if (res.success) {
        setDbStatus(res.data);
      }
    } catch (err) {
      console.warn('Failed to retrieve database status:', err);
    }
  };

  useEffect(() => {
    fetchDbStatus();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Persistent Left Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        isOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Viewport */}
      <div className="flex-1 flex flex-col md:pl-64 min-w-0">
        <Header
          pageTitle={TAB_TITLES[currentTab]}
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
          onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
          onOpenDbConfig={() => setIsDbModalOpen(true)}
          dbStatus={dbStatus}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentTab === 'overview' && (
            <OverviewPage
              selectedYear={selectedYear}
              onNavigateTab={setCurrentTab}
              onOpenReportGenerator={() => setCurrentTab('reports')}
            />
          )}

          {currentTab === 'energy' && (
            <EnergyPage selectedYear={selectedYear} />
          )}

          {currentTab === 'emissions' && (
            <EmissionsPage selectedYear={selectedYear} />
          )}

          {currentTab === 'waste' && (
            <WastePage selectedYear={selectedYear} />
          )}

          {currentTab === 'esg' && (
            <ESGPage />
          )}

          {currentTab === 'goals' && (
            <GoalsPage />
          )}

          {currentTab === 'reports' && (
            <ReportsPage />
          )}

          {currentTab === 'settings' && (
            <SettingsPage
              onOpenDbConfig={() => setIsDbModalOpen(true)}
              dbStatus={dbStatus}
              onRefreshDbStatus={fetchDbStatus}
            />
          )}
        </main>
      </div>

      {/* Database Connection & Seed Config Dialog */}
      <DatabaseConfigModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        status={dbStatus}
        onStatusUpdated={fetchDbStatus}
      />
    </div>
  );
};

const AuthGate: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [authView, setAuthView] = useState<'login' | 'register'>('login');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-medium text-slate-500">Initializing EcoTrack session...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    if (authView === 'register') {
      return <RegisterPage onSwitchToLogin={() => setAuthView('login')} />;
    }
    return <LoginPage onSwitchToRegister={() => setAuthView('register')} />;
  }

  return <MainDashboard />;
};

export default function App() {
  return (
    <AuthProvider>
      <AuthGate />
    </AuthProvider>
  );
}
