import React, { useState } from 'react';
import { Database, CheckCircle2, AlertTriangle, ExternalLink, RefreshCw, X } from 'lucide-react';
import { api } from '../../services/api';
import { DatabaseStatus } from '../../types';

interface DatabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: DatabaseStatus | null;
  onStatusUpdated: () => void;
}

export const DatabaseConfigModal: React.FC<DatabaseConfigModalProps> = ({
  isOpen,
  onClose,
  status,
  onStatusUpdated
}) => {
  const [uri, setUri] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uri.trim()) return;

    setIsConnecting(true);
    setFeedback(null);
    try {
      const res = await api.connectMongo(uri.trim());
      setFeedback({ type: 'success', message: res.message || 'Successfully connected to MongoDB!' });
      onStatusUpdated();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to connect to MongoDB.' });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleSeed = async (reset: boolean = false) => {
    setIsSeeding(true);
    setFeedback(null);
    try {
      const res = await api.seedDb(reset);
      setFeedback({ type: 'success', message: res.message || 'Sample database records populated.' });
      onStatusUpdated();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to seed records.' });
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">MongoDB Database Configuration</h3>
              <p className="text-xs text-slate-500">Mongoose ODM integration & persistent database storage</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Status Banner */}
          <div
            className={`p-4 rounded-xl border text-xs leading-relaxed ${
              status?.connected
                ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                : 'bg-amber-50/60 border-amber-200 text-amber-900'
            }`}
          >
            <div className="flex items-start gap-2.5">
              {status?.connected ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <span className="font-semibold block">
                  {status?.connected
                    ? `Live MongoDB Connected (${status.databaseName || 'ecotrack'})`
                    : 'Operating in Development Mode (Embedded Persistent Store)'}
                </span>
                <p className="text-[11px] opacity-90">{status?.message}</p>
                {status?.host && (
                  <p className="font-mono text-[10px] opacity-80">Host: {status.host}</p>
                )}
              </div>
            </div>
          </div>

          {feedback && (
            <div
              className={`p-3 rounded-lg text-xs ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border border-red-200 text-red-800'
              }`}
            >
              {feedback.message}
            </div>
          )}

          {/* Connect MongoDB Form */}
          <form onSubmit={handleConnect} className="space-y-3">
            <label className="block text-xs font-semibold text-slate-800">
              Connect to MongoDB Atlas or Local MongoDB:
            </label>
            <div className="space-y-1.5">
              <input
                type="text"
                value={uri}
                onChange={e => setUri(e.target.value)}
                placeholder="mongodb+srv://<user>:<password>@cluster.mongodb.net/ecotrack"
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
              <p className="text-[11px] text-slate-500">
                You can also configure this permanently in <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-700">.env</code> as <code className="text-slate-700">MONGODB_URI</code>.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="submit"
                disabled={isConnecting || !uri.trim()}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors"
              >
                {isConnecting ? 'Testing Connection...' : 'Connect MongoDB'}
              </button>
              <button
                type="button"
                onClick={() => handleSeed(true)}
                disabled={isSeeding}
                className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSeeding ? 'animate-spin' : ''}`} />
                <span>Reset & Seed 12-Month Demo Data</span>
              </button>
            </div>
          </form>

          {/* Setup Guide */}
          <div className="pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
            <span className="font-semibold text-slate-800 block">How to configure MongoDB Atlas (Free in 2 min):</span>
            <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-500">
              <li>Sign in at <a href="https://www.mongodb.com/cloud/atlas" target="_blank" rel="noreferrer" className="text-emerald-700 underline inline-flex items-center gap-0.5">mongodb.com/atlas <ExternalLink className="w-2.5 h-2.5" /></a> and create a free M0 cluster.</li>
              <li>Under Database Access, create a user with "Read and write to any database".</li>
              <li>Under Network Access, add IP Address 0.0.0.0/0 (Allow access from anywhere).</li>
              <li>Click Connect → Drivers → Copy the connection string. Replace password and paste above.</li>
            </ol>
          </div>
        </div>

        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
