import React from 'react';
import { LucideIcon } from 'lucide-react';

interface KPICardProps {
  label: string;
  value: string | number;
  unit?: string;
  subtext?: string;
  trend?: {
    value: string;
    isPositive?: boolean;
    isNeutral?: boolean;
    label?: string;
  };
  icon?: LucideIcon;
  badge?: string;
}

export const KPICard: React.FC<KPICardProps> = ({
  label,
  value,
  unit,
  subtext,
  trend,
  icon: Icon,
  badge
}) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 transition-shadow hover:shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-3">
        <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">{label}</span>
        {Icon && (
          <div className="p-2 rounded-lg bg-slate-50 text-slate-600 border border-slate-100">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="flex items-baseline gap-1.5 mb-2">
        <span className="text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
          {typeof value === 'number' ? value.toLocaleString() : value}
        </span>
        {unit && <span className="text-sm font-medium text-slate-500">{unit}</span>}
      </div>

      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 text-slate-500">
        {trend ? (
          <div className="flex items-center gap-1.5 font-medium">
            <span
              className={
                trend.isNeutral
                  ? 'text-slate-600'
                  : trend.isPositive
                  ? 'text-emerald-700'
                  : 'text-amber-700'
              }
            >
              {trend.value}
            </span>
            <span className="text-slate-400 font-normal">{trend.label || 'vs previous period'}</span>
          </div>
        ) : (
          <span>{subtext || 'Verified reporting record'}</span>
        )}
        {badge && <span className="text-slate-400 text-[11px]">{badge}</span>}
      </div>
    </div>
  );
};
