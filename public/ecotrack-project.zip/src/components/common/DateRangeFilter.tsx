import React from 'react';
import { Calendar } from 'lucide-react';

interface DateRangeFilterProps {
  selectedYear: string;
  onYearChange: (year: string) => void;
  options?: Array<{ label: string; value: string }>;
}

export const DateRangeFilter: React.FC<DateRangeFilterProps> = ({
  selectedYear,
  onYearChange,
  options = [
    { label: 'Reporting Year 2026', value: '2026' },
    { label: 'Reporting Year 2025', value: '2025' },
    { label: 'All Historic Periods', value: '' }
  ]
}) => {
  return (
    <div className="flex items-center gap-2">
      <div className="relative inline-flex items-center">
        <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 pointer-events-none" />
        <select
          value={selectedYear}
          onChange={e => onYearChange(e.target.value)}
          className="pl-8 pr-7 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 appearance-none cursor-pointer"
        >
          {options.map(opt => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <span className="absolute right-2.5 text-slate-400 pointer-events-none text-[10px]">▼</span>
      </div>
    </div>
  );
};
