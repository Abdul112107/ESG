import React from 'react';
import { Menu, Database, ShieldCheck, Download } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { DatabaseStatus } from '../../types';
import { DateRangeFilter } from '../common/DateRangeFilter';

interface HeaderProps {
  pageTitle: string;
  selectedYear: string;
  onYearChange: (year: string) => void;
  onOpenMobileMenu: () => void;
  onOpenDbConfig: () => void;
  dbStatus: DatabaseStatus | null;
}

export const Header: React.FC<HeaderProps> = ({
  pageTitle,
  selectedYear,
  onYearChange,
  onOpenMobileMenu,
  onOpenDbConfig,
  dbStatus
}) => {
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-30 h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-8">
      {/* Zone 1: Brand / Breadcrumb */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 md:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-base font-bold text-slate-900 tracking-tight whitespace-nowrap">
            {pageTitle}
          </h1>
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-400">
            <span>EcoTrack ESG</span>
            <span aria-hidden="true">·</span>
            <span>Enterprise Suite</span>
          </div>
        </div>
      </div>

      {/* Zone 2: Contextual Controls & Status */}
      <div className="flex items-center gap-3">
        <DateRangeFilter selectedYear={selectedYear} onYearChange={onYearChange} />

        {/* Database Status Button */}
        <button
          onClick={onOpenDbConfig}
          title="Click to view or configure MongoDB connection"
          className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
            dbStatus?.connected
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
              : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span className="truncate max-w-[140px]">
            {dbStatus?.connected ? 'MongoDB Live' : 'Dev DB (Local)'}
          </span>
        </button>

        {/* Download Project ZIP */}
        <a
          href="/api/download-zip"
          download="ecotrack-esg-platform.zip"
          title="Download complete project source code as a ZIP archive"
          className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Project ZIP</span>
        </a>
      </div>

      {/* Zone 3: User Profile Badge */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="hidden lg:flex flex-col text-right">
          <span className="text-xs font-semibold text-slate-900 leading-tight">
            {user?.name || 'Authorized Auditor'}
          </span>
          <span className="text-[11px] text-slate-500 flex items-center justify-end gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600 inline" />
            {user?.role || 'Auditor'}
          </span>
        </div>

        <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold uppercase tracking-wider">
          {user?.name ? user.name.charAt(0) : 'U'}
        </div>
      </div>
    </header>
  );
};
